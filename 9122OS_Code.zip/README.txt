Book Name: R for Data Science Cookbook
Chapter No   Code Present
 1				Yes
 2				Yes
 3				Yes
 4				Yes
 5				Yes
 6				Yes
 7				Yes
 8				Yes
 9				Yes
 10				Yes
 11				Yes
 12				Yes
 
 